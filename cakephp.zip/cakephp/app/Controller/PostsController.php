<?php
	
	Class PostsController extends AppController{
		public $helpers = array('Html','Form','Session');
		public $name = 'Posts';

		public function index(){

			$this->paginate = array('order' => array('Post.created' => 'desc'),'limit' => 3);

			$this->set('posts',$this->paginate('Post'));
			$this->set('title_for_layout', 'Blog em Cake');

		}
		

		public function view($id = null){
			$this->set('posts',$this->Post->findById($id));
		} 

		public function add(){
			if($this->request->is('post')){
				$this->Post->create();
				if($this->Post->save($this->request->data)){
					$this->Flash->success("Seu post foi salvo!");
					$this->redirect(array('action'=>'index'));
				}
				$this->Flash->error('Não foi possivel salvar seu post!');
			}
			$autors = $this->Post->Autor->find('list', array('fields' => array('id','nome_autores')));
			$this->set('autors',$autors);
			if(count($autors)==0){
				$this->Flash->info('Cadastre-se Para Escrever nosso Primeiro Post');
				$this->redirect(array('controller' => 'autors', 'action' => 'add'));				
			}


		}
		
		public function edit($id = null) {
		    $this->Post->id = $id;
		    if ($this->request->is('get')) {
		        $this->request->data = $this->Post->findById($id);
		    } else {
		        if ($this->Post->save($this->request->data)) {
		            $this->Flash->success('Seu post foi atualizado!');
		            $this->redirect(array('action' => 'index'));
		        }
		    }
			$autors = $this->Post->Autor->find('list', array('fields' => array('id','nome_autores')));
			$this->set('autors',$autors);
		}

		public function delete($id){
			if(!$this->request->is('post')){
				throw new MethodNotAllowedException();				
			}
			if($this->Post->delete($id)){
				$this->Flash->success("O Post (id:".$id.") foi deletado!");
				$this->redirect(array('action' => 'index'));
			}
		}
	}

?>