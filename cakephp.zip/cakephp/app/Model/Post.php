<?php
	
	class Post extends AppModel{
		public $name = 'Post';
		
		public $belongsTo = array(
				'Autor'  => array(
					'className' => 'Autor',
					'foreginKey'=> 'autor_id'
				)


		);


		public $validate = array(
				'title' => array('rule' => 'notBlank'),
				'body'  => array('rule' => 'notBlank'),
				'autor_id' => array('rule' => 'notEmpty')
			);
	}


?>