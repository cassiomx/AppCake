<?php

	Class Autor extends AppModel{
		public $name = 'Autor';

		public $hasMany = array(
			'Post' => array(
				'className' => 'Post',
				'foreignKey' => 'autor_id',
				'conditions' => '',
				'order' => 'Post.id DESC',
				'depend' => false

			)

		);


		public $validate = array(
				'nome' => array('rule' => 'notBlank'),
				'email' => array('rule' => 'notBlank')
			);


		public $virtualFields = array('nome_autores' => 'Autor.nome');
	}







?>